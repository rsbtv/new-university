--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

-- Started on 2023-11-24 14:24:11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 5 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- TOC entry 4868 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 225 (class 1259 OID 16588)
-- Name: Artist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Artist" (
    artist_id integer NOT NULL,
    "solo/band" text NOT NULL,
    founding_date date NOT NULL,
    current_label_id integer NOT NULL,
    "Name" text NOT NULL
);


ALTER TABLE public."Artist" OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 16595)
-- Name: FavoriteArtists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."FavoriteArtists" (
    list_id integer NOT NULL,
    artist_id integer NOT NULL
);


ALTER TABLE public."FavoriteArtists" OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 16567)
-- Name: Genre; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Genre" (
    genre_id integer NOT NULL,
    genre_name text NOT NULL
);


ALTER TABLE public."Genre" OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 16581)
-- Name: Label; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Label" (
    label_id integer NOT NULL,
    label_title integer NOT NULL,
    director text NOT NULL,
    founding_date date NOT NULL
);


ALTER TABLE public."Label" OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 16541)
-- Name: Playlist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Playlist" (
    id integer NOT NULL,
    title text NOT NULL,
    creation_date date NOT NULL,
    creator_id integer NOT NULL,
    type_id integer NOT NULL,
    playlist_content_id integer NOT NULL
);


ALTER TABLE public."Playlist" OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 16555)
-- Name: PlaylistContent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PlaylistContent" (
    content_id integer NOT NULL,
    track_id integer NOT NULL
);


ALTER TABLE public."PlaylistContent" OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 16548)
-- Name: PlaylistType; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PlaylistType" (
    type_id integer NOT NULL,
    type_name text NOT NULL
);


ALTER TABLE public."PlaylistType" OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 16536)
-- Name: Playlists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Playlists" (
    list_id integer NOT NULL,
    playlist_id integer NOT NULL
);


ALTER TABLE public."Playlists" OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 16574)
-- Name: Release; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Release" (
    release_id integer NOT NULL,
    release_title text NOT NULL,
    release_date date NOT NULL,
    artist_id integer NOT NULL,
    label_id integer NOT NULL
);


ALTER TABLE public."Release" OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 16560)
-- Name: Track; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Track" (
    track_id integer NOT NULL,
    track_title text NOT NULL,
    track_duration integer NOT NULL,
    track_genre_id integer NOT NULL,
    release_id integer NOT NULL
);


ALTER TABLE public."Track" OWNER TO postgres;

--
-- TOC entry 216 (class 1259 OID 16529)
-- Name: User ; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User " (
    id integer NOT NULL,
    playlists integer,
    favorite_artists integer,
    name text NOT NULL,
    e_mail text NOT NULL,
    password text NOT NULL
);


ALTER TABLE public."User " OWNER TO postgres;

--
-- TOC entry 4861 (class 0 OID 16588)
-- Dependencies: 225
-- Data for Name: Artist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Artist" (artist_id, "solo/band", founding_date, current_label_id, "Name") FROM stdin;
\.


--
-- TOC entry 4862 (class 0 OID 16595)
-- Dependencies: 226
-- Data for Name: FavoriteArtists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."FavoriteArtists" (list_id, artist_id) FROM stdin;
\.


--
-- TOC entry 4858 (class 0 OID 16567)
-- Dependencies: 222
-- Data for Name: Genre; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Genre" (genre_id, genre_name) FROM stdin;
\.


--
-- TOC entry 4860 (class 0 OID 16581)
-- Dependencies: 224
-- Data for Name: Label; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Label" (label_id, label_title, director, founding_date) FROM stdin;
\.


--
-- TOC entry 4854 (class 0 OID 16541)
-- Dependencies: 218
-- Data for Name: Playlist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Playlist" (id, title, creation_date, creator_id, type_id, playlist_content_id) FROM stdin;
\.


--
-- TOC entry 4856 (class 0 OID 16555)
-- Dependencies: 220
-- Data for Name: PlaylistContent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PlaylistContent" (content_id, track_id) FROM stdin;
\.


--
-- TOC entry 4855 (class 0 OID 16548)
-- Dependencies: 219
-- Data for Name: PlaylistType; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PlaylistType" (type_id, type_name) FROM stdin;
\.


--
-- TOC entry 4853 (class 0 OID 16536)
-- Dependencies: 217
-- Data for Name: Playlists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Playlists" (list_id, playlist_id) FROM stdin;
\.


--
-- TOC entry 4859 (class 0 OID 16574)
-- Dependencies: 223
-- Data for Name: Release; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Release" (release_id, release_title, release_date, artist_id, label_id) FROM stdin;
\.


--
-- TOC entry 4857 (class 0 OID 16560)
-- Dependencies: 221
-- Data for Name: Track; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Track" (track_id, track_title, track_duration, track_genre_id, release_id) FROM stdin;
\.


--
-- TOC entry 4852 (class 0 OID 16529)
-- Dependencies: 216
-- Data for Name: User ; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User " (id, playlists, favorite_artists, name, e_mail, password) FROM stdin;
\.


--
-- TOC entry 4693 (class 2606 OID 16594)
-- Name: Artist Artist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Artist"
    ADD CONSTRAINT "Artist_pkey" PRIMARY KEY (artist_id);


--
-- TOC entry 4695 (class 2606 OID 16599)
-- Name: FavoriteArtists Favorite_artists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FavoriteArtists"
    ADD CONSTRAINT "Favorite_artists_pkey" PRIMARY KEY (list_id);


--
-- TOC entry 4687 (class 2606 OID 16573)
-- Name: Genre Genre_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Genre"
    ADD CONSTRAINT "Genre_pkey" PRIMARY KEY (genre_id);


--
-- TOC entry 4691 (class 2606 OID 16587)
-- Name: Label Label_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Label"
    ADD CONSTRAINT "Label_pkey" PRIMARY KEY (label_id);


--
-- TOC entry 4683 (class 2606 OID 16559)
-- Name: PlaylistContent Playlist_content_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PlaylistContent"
    ADD CONSTRAINT "Playlist_content_pkey" PRIMARY KEY (content_id);


--
-- TOC entry 4679 (class 2606 OID 16547)
-- Name: Playlist Playlist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Playlist"
    ADD CONSTRAINT "Playlist_pkey" PRIMARY KEY (id);


--
-- TOC entry 4681 (class 2606 OID 16554)
-- Name: PlaylistType Playlist_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PlaylistType"
    ADD CONSTRAINT "Playlist_type_pkey" PRIMARY KEY (type_id);


--
-- TOC entry 4677 (class 2606 OID 16540)
-- Name: Playlists Playlists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Playlists"
    ADD CONSTRAINT "Playlists_pkey" PRIMARY KEY (list_id);


--
-- TOC entry 4689 (class 2606 OID 16580)
-- Name: Release Release_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Release"
    ADD CONSTRAINT "Release_pkey" PRIMARY KEY (release_id);


--
-- TOC entry 4685 (class 2606 OID 16566)
-- Name: Track Track_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Track"
    ADD CONSTRAINT "Track_pkey" PRIMARY KEY (track_id);


--
-- TOC entry 4675 (class 2606 OID 16535)
-- Name: User  User _pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User "
    ADD CONSTRAINT "User _pkey" PRIMARY KEY (id);


--
-- TOC entry 4696 (class 2606 OID 16660)
-- Name: User  User _favorite_artists_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User "
    ADD CONSTRAINT "User _favorite_artists_fkey" FOREIGN KEY (favorite_artists) REFERENCES public."FavoriteArtists"(list_id) NOT VALID;


--
-- TOC entry 4708 (class 2606 OID 16665)
-- Name: FavoriteArtists a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FavoriteArtists"
    ADD CONSTRAINT a FOREIGN KEY (artist_id) REFERENCES public."Artist"(artist_id) NOT VALID;


--
-- TOC entry 4699 (class 2606 OID 16615)
-- Name: Playlist e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Playlist"
    ADD CONSTRAINT e FOREIGN KEY (creator_id) REFERENCES public."User "(id) NOT VALID;


--
-- TOC entry 4703 (class 2606 OID 16640)
-- Name: Track i; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Track"
    ADD CONSTRAINT i FOREIGN KEY (release_id) REFERENCES public."Release"(release_id) NOT VALID;


--
-- TOC entry 4705 (class 2606 OID 16645)
-- Name: Release i; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Release"
    ADD CONSTRAINT i FOREIGN KEY (label_id) REFERENCES public."Label"(label_id) NOT VALID;


--
-- TOC entry 4706 (class 2606 OID 16650)
-- Name: Release o; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Release"
    ADD CONSTRAINT o FOREIGN KEY (artist_id) REFERENCES public."Artist"(artist_id) NOT VALID;


--
-- TOC entry 4707 (class 2606 OID 16655)
-- Name: Artist p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Artist"
    ADD CONSTRAINT p FOREIGN KEY (current_label_id) REFERENCES public."Label"(label_id) NOT VALID;


--
-- TOC entry 4697 (class 2606 OID 16605)
-- Name: User  q; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User "
    ADD CONSTRAINT q FOREIGN KEY (playlists) REFERENCES public."Playlists"(list_id) NOT VALID;


--
-- TOC entry 4700 (class 2606 OID 16620)
-- Name: Playlist r; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Playlist"
    ADD CONSTRAINT r FOREIGN KEY (type_id) REFERENCES public."PlaylistType"(type_id) NOT VALID;


--
-- TOC entry 4701 (class 2606 OID 16625)
-- Name: Playlist t; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Playlist"
    ADD CONSTRAINT t FOREIGN KEY (playlist_content_id) REFERENCES public."PlaylistContent"(content_id) NOT VALID;


--
-- TOC entry 4704 (class 2606 OID 16635)
-- Name: Track u; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Track"
    ADD CONSTRAINT u FOREIGN KEY (track_genre_id) REFERENCES public."Genre"(genre_id) NOT VALID;


--
-- TOC entry 4698 (class 2606 OID 16610)
-- Name: Playlists w; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Playlists"
    ADD CONSTRAINT w FOREIGN KEY (playlist_id) REFERENCES public."Playlist"(id) NOT VALID;


--
-- TOC entry 4702 (class 2606 OID 16630)
-- Name: PlaylistContent y; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PlaylistContent"
    ADD CONSTRAINT y FOREIGN KEY (track_id) REFERENCES public."Track"(track_id) NOT VALID;


-- Completed on 2023-11-24 14:24:11

--
-- PostgreSQL database dump complete
--

